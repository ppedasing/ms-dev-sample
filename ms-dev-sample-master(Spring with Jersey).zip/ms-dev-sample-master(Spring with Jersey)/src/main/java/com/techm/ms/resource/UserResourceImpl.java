package com.techm.ms.resource;

import com.techm.ms.model.User;
import com.techm.ms.model.representation.ResourceCollection;
import org.springframework.stereotype.Controller;

import javax.ws.rs.core.Link;
import javax.ws.rs.core.Response;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

@Controller
public class UserResourceImpl implements UserResource {

    private static Map<Integer, User> userMap = new HashMap<>();
    private static String baseUrl = "/users";

    @Override
    public Response getUser(Integer userId) {
        ArrayList<User> usersList = null;

        userMap = this.buildMap();
        if(userMap.containsKey(userId)) {
            usersList = new ArrayList<>();
            User user = (User)userMap.get(userId);
            usersList.add(user);
            if(user == null){
                return Response.noContent().build();
            }
        }

        Link link = Link.fromUri(baseUrl).rel("self").build();
        ResourceCollection<User> resource = new ResourceCollection<>(usersList);
        return Response.ok(resource).links(link).build();


    }

    @Override
    public Response createUser(User user) {
        ArrayList<User> usersList = null;

        userMap = this.buildMap();
        if(userMap.containsKey(user.getId())) {
            return null;
        } else {
            usersList = new ArrayList<>();
            usersList.add(user);
            userMap.put(Integer.valueOf((int) user.getId()),user);
            Link link = Link.fromUri(baseUrl).rel("self").build();
            ResourceCollection<User> resource = new ResourceCollection<>(usersList);
            return Response.ok(resource).links(link).build();
        }


    }


 /*   @Override
    public Response findAllUsers() {

        User user = null;
        Map<Long,User> usersMap = this.buildMap();
        List<User> usersList = usersMap.values().stream().collect(Collectors.toList());
        Link link = Link.fromUri(baseUrl).rel("self").build();
        ResourceCollection<User> resource = new ResourceCollection<>(usersList);
        return Response.ok(resource).links(link).build();


    }*/

    private Map<Integer,User> buildMap(){
        userMap.put(123, new User(123l,"abcd", 20, 1));
        userMap.put(124, new User(124l,"abcd", 22, 2));
        userMap.put(125, new User(125l,"abcd", 25, 3));
        return userMap;
    }
}
